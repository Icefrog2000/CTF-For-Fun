# About pyast64
URL: https://github.com/benhoyt/pyast64/blob/e91c97a060debfe6f0abbae782f1d21d6b0fed8a/pyast64.py

# How to test?
```sh
$ docker build pyast64 .
$ docker run -p 9999:9999 pyast64 /etc/init.sh
```
