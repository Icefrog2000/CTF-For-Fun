#! /bin/bash
service xinetd restart && /bin/sleep infinity
