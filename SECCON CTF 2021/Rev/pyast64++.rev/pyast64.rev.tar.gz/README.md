# About pyast64
URL: https://github.com/benhoyt/pyast64/blob/e91c97a060debfe6f0abbae782f1d21d6b0fed8a/pyast64.py

# Hint
The binary `chall.elf` is made by `pyast64.py`.
The core part of `pyast64.py` is the same as that of `pyast64++.pwn`.
