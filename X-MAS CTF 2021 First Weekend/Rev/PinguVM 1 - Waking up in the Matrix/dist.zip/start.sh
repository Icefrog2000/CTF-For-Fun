#!/bin/bash
# Add your startup script

# DO NOT DELETE
xinetd -dontfork
