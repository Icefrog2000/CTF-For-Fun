#!/bin/sh
docker build . -t readflag
